package p03_wildFarm;

public abstract class Felime extends Mammal {


    protected Felime(String animalName, String animalType, double animalWeight, int foodEaten, String livingRegion) {
        super(animalName, animalType, animalWeight, foodEaten, livingRegion);
    }


}
