package p03_wildFarm;

public class Vegetable extends Food{


    public Vegetable(int quantity) {
        super(quantity);
    }
}
