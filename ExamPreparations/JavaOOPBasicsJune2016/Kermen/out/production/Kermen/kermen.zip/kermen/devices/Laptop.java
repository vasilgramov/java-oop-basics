package kermen.devices;

public class Laptop extends Device {

    public Laptop(double electricityCost) {
        super(electricityCost);
    }
}
