package kermen.people;

public class YoungPerson extends Person {

    public YoungPerson(double income) {
        super(income);
    }
}
