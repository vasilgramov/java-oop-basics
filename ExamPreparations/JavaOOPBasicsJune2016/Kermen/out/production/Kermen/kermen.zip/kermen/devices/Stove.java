package kermen.devices;

public class Stove extends Device {

    public Stove(double electricityCost) {
        super(electricityCost);
    }
}
