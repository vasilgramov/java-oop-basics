package kermen.people;

public class OldPerson extends Person {

    public OldPerson(double income) {
        super(income);
    }
}
