package kermen.devices;

public class Fridge extends Device {

    public Fridge(double electricityCost) {
        super(electricityCost);
    }
}
