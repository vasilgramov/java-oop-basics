package kermen.devices;

public class TV extends Device {

    public TV(double cost) {
        super(cost);
    }
}
